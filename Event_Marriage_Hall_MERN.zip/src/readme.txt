1. Open Mongo DB Create DB 
   Crete DB - hall_booking
   
3. Import all db.json follow below step
Example > hall_booking.Admin > Create "Admin" Collection and import JSON File 

4. Open backend and client folder in two terminal VS code 

Event_Marriage_Hall_Booking_System_MERN\backend> npm start
Event_Marriage_Hall_Booking_System_MERN\client>  npm run dev

Open Application 
http://localhost:5173/

Admin
Id:  admin@gmail.com
Pwd: test

Owner
Id:  owner@gmail.com
Pwd: Test@100 

User
Id:  user@gmail.com
Pwd: Test@100 

MERN React JS
Front End : React JS, CSS, Bootstrap
Back End  : Express JS, Node JS,
Data Base : Mongo DB
	
Tools:
VS Studio 
Mongo DB

     			Event_Marriage_Hall_Booking_System_MERN
