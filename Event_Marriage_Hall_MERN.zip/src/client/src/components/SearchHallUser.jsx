import React, { useState, useEffect } from 'react';
import { Link , useNavigate} from 'react-router-dom';
import axios from 'axios';
import { useCookies } from 'react-cookie';
import "./css/bootstrap.min.css";
import "./css/owl.carousel.min.css";
import "./css/font-awesome.min.css";
import "./css/animate.css";
import "./css/font-awesome.min.css";
import "./css/lineicons.min.css";
import "./css/magnific-popup.css";
import "./css/style.css";

import "./js/jquery.min.js";  
import "./js/bootstrap.bundle.min.js";

import imgSmall from "./img/core-img/logo-small.png";
import imgBg from "./img/bg-img/9.png";
import imgMech from "./img/mechanic.png";
import Logout from './Logout.jsx';
import Title from './Title.jsx';

const SearchHallUser = () => {
  const navigate = useNavigate();
  {/*const userBooking = (id) => {
    navigate("/booking_user/" );
  }*/}
  const Feedbackfunction = (id) => {
    navigate("/post_feedback/"+ id);
  }
  const [hallData, setHallData] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [cookies, setCookie] = useCookies(['name']);

  useEffect(() => {
    const fetchHallData = async () => {
        try {
            const response = await axios.get(`http://localhost:4000/api/v1/hall/`);
            if (response.status === 200) {
                setHallData(response.data);
            } else {
                console.error('Error fetching Hall data:', response.statusText);
            }
        } catch (error) {
            console.error('Error fetching Hall data:', error.message);
        }
    };

    fetchHallData();
}, []);

// Filter data based on the search term and status
const filteredData = hallData.filter((hall) => {
    const isMatch = Object.values(hall).some((field) =>
        field.toString().toLowerCase().includes(searchTerm.toLowerCase())
    );
    const isApproved = hall.status.toLowerCase() === 'approved';
    return isMatch && isApproved;
});

const userBooking = (hall) => {
    setCookie('name', hall.name, { path: '/' });
    navigate("/booking_user");
};
 

  ////////////////////////////////////////////////
  ///////Get Donar Email ID and Store End ///////
  ////////////////////////////////////////////////

  const timeOptions = { hour: '2-digit', minute: '2-digit' };
  return (
    <div>
        <div>
      
        <div className="header-area" id="headerArea">
        <div className="container h-100 d-flex align-items-center justify-content-between">
    
        <div className="header-area" id="headerArea">
        <div className="container h-100 d-flex align-items-center justify-content-between">
            <div className="logo-wrapper" style={{color:'#020310'}}><img src={imgSmall} alt=""/> <Title /> </div>
        
            <div className="suha-navbar-toggler" data-bs-toggle="offcanvas" data-bs-target="#suhaOffcanvas" aria-controls="suhaOffcanvas"><span></span><span></span><span></span></div>
        </div>
        </div>  

{/* tabindex="-1" */}
        <div className="offcanvas offcanvas-start suha-offcanvas-wrap"  id="suhaOffcanvas" aria-labelledby="suhaOffcanvasLabel">
      <button className="btn-close btn-close-white text-reset" type="button" data-bs-dismiss="offcanvas" aria-label="Close"></button>

      <div className="offcanvas-body">
        <div className="sidenav-profile">
          <div className="user-profile"><img src={imgBg} alt=""/></div>
          <div className="user-info">
            <h6 className="user-name mb-1">Event Marriage Hall Booking System</h6>
         
          </div>
        </div>
    
        <ul className="sidenav-nav ps-0">
          <li><Link to="/user_home"><i className="lni lni-home"></i>Home</Link></li>
          <li><Logout /></li>  
          </ul>
      </div>
    </div>
      </div>
    </div>
    
    <div className="page-content-wrapper">
  <div className="top-products-area py-3">
    <div className="">
      
    <div className="section-heading d-flex align-items-center justify-content-between">
        <h6>Search Hall Details</h6>
      </div>
      <div className="row g-3" >
          <div className="top-search-form">
            <form>
              <input className="form-control"  type="text"  placeholder="Search..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
              <button type="submit"><i className="fa fa-search"></i></button>
            </form>
          </div>
        </div>

        <div className="row" style={{marginTop:10}}>
            {filteredData.map((hall) => (
              <div key={hall._id} className="col-12 col-md-4">                                        
        
                <div className="card product-card" style={{marginBottom:10}}>
                  <div className="card-body">
                    {/* Display the hall image */}
                    {hall.image && (
                      <a href={`http://localhost:4000/${hall.image}`} target="_blank" rel="noopener noreferrer" className="product-title d-block">
                        <img src={`http://localhost:4000/${hall.image}`} alt="hall Image" style={{ maxWidth: '100%', maxHeight: '100%', width: 'auto', height: 'auto' }} />
                      </a>
                    )}
                    <a className="product-title d-block"  >Hall Name : <b>{hall.name}</b></a>
                    <a className="product-title d-block"  >E-Mail : <b>{hall.owneremail}</b></a>
                    <a className="product-title d-block"  >Hall Mobile : <b>{hall.mobile}</b></a>
                    <a className="product-title d-block"  >Address : {hall.address}</a>
                    <a className="product-title d-block"  >City : {hall.city}</a>	
                    <a className="product-title d-block"  >Facility : {hall.facility}</a>
                    <a className="product-title d-block"  >Price ranges: {hall.price}</a>
                    <a className="product-title d-block"  >Lat : {hall.lat}  </a>
                    <a className="product-title d-block"  >Long : {hall.long}  </a>
                  </div>
                  </div> 
    
                  <button className="btn btn-danger" onClick={() => userBooking(hall)}>Booking</button>
                    <a className="btn btn-danger" target="_blank" href={`https://maps.google.com/?q=${hall.lat},${hall.long}`}>Show Map</a>
                    <a className="btn btn-danger" onClick={() => { Feedbackfunction(hall.id) }}>Feedback</a>
              </div>
            ))}
        </div>
      </div>
  </div>
  
  <div className="footer-nav-area" id="footerNav">
    <div className="container h-100 px-0">
      <div className="suha-footer-nav h-100">
        <ul className="h-100 d-flex align-items-center justify-content-between ps-0">
          <li className="active"> <Link to="/user_home" ><i className="lni lni-home"></i>Home </Link> </li>
          <li><Logout /></li> 
        </ul>
      </div>
    </div>
  </div>
</div>




</div>
</div>
  )
}

export default SearchHallUser