import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import "./css/bootstrap.min.css";
import "./css/owl.carousel.min.css";
import "./css/font-awesome.min.css";
import "./css/animate.css";
import "./css/font-awesome.min.css";
import "./css/lineicons.min.css";
import "./css/magnific-popup.css";
import "./css/style.css";
import "./js/jquery.min.js";  
import "./js/bootstrap.bundle.min.js";
{/*
import "./js/waypoints.min.js";
import "./js/jquery.easing.min.js";
import "./js/owl.carousel.min.js";
import "./js/jquery.magnific-popup.min.js";
*/}
import imgSmall from "./img/core-img/logo-small.png";
import imgBg from "./img/bg-img/9.png";
import Logout from './Logout.jsx';
import Title from './Title.jsx';

// name  donarname itemname description quantity  landmark address city address pincode mobile 

const PostBookingUser = () => {

  const [formData, setFormData] = useState({
    owneremail: '',
    email: '',
    name: '',
    slotDate: '',

    cusname: '',
    functionfor: '',
    functiontype: '',
    guestcount: '',
    mobile: '',
    address: '',

    status: '',

    
    
  });
  const [validationErrors, setValidationErrors] = useState({});


  const postBookingData = async () => {
    const token = localStorage.getItem('token');
    const ownerEmail = decodeURIComponent(document.cookie.replace(/(?:(?:^|.*;\s*)owneremail\s*=\s*([^;]*).*$)|^.*$/, '$1'));
    const userEmail = decodeURIComponent(document.cookie.replace(/(?:(?:^|.*;\s*)email\s*=\s*([^;]*).*$)|^.*$/, '$1'));
    const name = decodeURIComponent(document.cookie.replace(/(?:(?:^|.*;\s*)name\s*=\s*([^;]*).*$)|^.*$/, '$1'));
    const slotDate = decodeURIComponent(document.cookie.replace(/(?:(?:^|.*;\s*)slotDate\s*=\s*([^;]*).*$)|^.*$/, '$1'));
    //console.log(donarEmail);  // Output: donar@gmail.com

    try {
      const response = await fetch('http://localhost:4000/api/v1/booking/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-auth-token': token,
        },
        body: JSON.stringify({
          ...formData,
          owneremail: ownerEmail,
          email: userEmail,
          name: name,
          slotDate: slotDate,
        }),
      });

      if (response.ok) {
        console.log('Booking data posted successfully!');
        // Handle success, e.g., redirect to another page
        alert('Booked successfully!');
        window.location.href = "view_booking_user";

      } else {
        console.error('Error posting booking data:', response.statusText);
      }
    } catch (error) {
      console.error('Error posting booking data:', error.message);
    }
  };

  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    
        // Reset validation error htmlFor the current field when it's being modified
        setValidationErrors({
          ...validationErrors,
          [name]: '',
        });

  };


      // Validation 
        const validateForm = () => {
        let isValid = true;
        const errors = {};
    
        // Validate phone number
        if (!/^\d{10}$/.test(formData.mobile)) {
          errors.mobile = 'Phone must be a 10-digit number';
          isValid = false;
        }
        setValidationErrors(errors);
    
        return isValid;
      };
    

  // OnForm Submit
  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      // Validation failed, do not proceed with the submission
      return;
    }
    // Else Validation passed 
    postBookingData();
  };




  return (
    <div>
        <div>
      
        <div className="header-area" id="headerArea">
        <div className="container h-100 d-flex align-items-center justify-content-between">
    
        <div className="header-area" id="headerArea">
        <div className="container h-100 d-flex align-items-center justify-content-between">
            <div className="logo-wrapper" style={{color:'#020310'}}><img src={imgSmall} alt=""/> <Title /> </div>
        
            <div className="suha-navbar-toggler" data-bs-toggle="offcanvas" data-bs-target="#suhaOffcanvas" aria-controls="suhaOffcanvas"><span></span><span></span><span></span></div>
        </div>
        </div>  

{/* tabindex="-1" */}
        <div className="offcanvas offcanvas-start suha-offcanvas-wrap"  id="suhaOffcanvas" aria-labelledby="suhaOffcanvasLabel">
      <button className="btn-close btn-close-white text-reset" type="button" data-bs-dismiss="offcanvas" aria-label="Close"></button>

      <div className="offcanvas-body">
        <div className="sidenav-profile">
          <div className="user-profile"><img src={imgBg} alt=""/></div>
          <div className="user-info">
            <h6 className="user-name mb-1">Event Marriage Hall Booking System</h6>
         
          </div>
        </div>
    
        <ul className="sidenav-nav ps-0">
          <li><Link to="/user_home"><i className="lni lni-home"></i>Home</Link></li>
          <li><Logout /></li>  
          </ul>
      </div>
    </div>
      </div>
    </div>
    <div className="page-content-wrapper">
      <div className="top-products-area py-3">
        <div className="container">
          <div className="section-heading d-flex align-items-center justify-content-between">
            <h5 style={{color:'#203354'}}>Add Event Hall Details</h5>
          </div>
        {/* Form Scrip Start*/}
        <div className="profile-wrapper-area py-1">
          <div className="card user-data-card">
            <div className="card-body">
              <form  onSubmit={handleSubmit}>
              
              <div className="mb-3">
                  <div className="title mb-2"><span> Name:</span></div>
                  <input className="form-control"
                    name="cusname" id="cusname"
                    value={formData.cusname}
                    onChange={handleInputChange}    type="text"  />
                </div>
                <div className="mb-3">
                  <div className="title mb-2"><span>Function For:</span></div>
                  <input className="form-control" name="functionfor" id="functionfor"
                    value={formData.functionfor}
                    onChange={handleInputChange}   type="text"/>
                </div>
                <div className="mb-3">
  <div className="title mb-2"><span>Function type:</span></div>
  <select
    className="form-control"
    name="functiontype"
    id="functiontype"
    value={formData.functiontype}
    onChange={handleInputChange}>
    <option value="">Select function type....</option>
    <option value="Wedding ceremonies">Wedding ceremonies</option>
    <option value="Wedding receptions">Wedding receptions</option>
    <option value="Engagement parties">Engagement parties</option>
    <option value="Anniversary celebrations">Anniversary celebrations</option>
    <option value="Birthday parties">Birthday parties</option>
    <option value="Corporate events">Corporate events (e.g., conferences, seminars, meetings)</option>
    <option value="Cultural events">Cultural events (e.g., concerts, performances)</option>
    <option value="Religious ceremonies">Religious ceremonies (e.g., baptisms, religious festivals)</option>
    <option value="Social gatherings">Social gatherings (e.g., family reunions, holiday parties)</option>
    <option value="Graduation parties">Graduation parties </option>
    <option value="Others">Others </option>
    {/* Add more options as needed */}
  </select>
</div>
	    			 <div className="mb-3">
                  <div className="title mb-2"><span>Approx Guest Count's:</span></div>
                  <input className="form-control" name="guestcount" id="guestcount"
                    value={formData.guestcount}
                    onChange={handleInputChange}   type="number" />
                </div>
				 <div className="mb-3">
                  <div className="title mb-2"><span>Mobile:</span></div>
                  <input className="form-control" name="mobile" id="mobile"
                    value={formData.mobile}
                    onChange={handleInputChange}  type="number" />
                </div>

                <div className="mb-3">
                  <div className="title mb-2"><span>Address:</span></div>
                  <input className="form-control" name="address" id="address"
                    value={formData.address}
                    onChange={handleInputChange}  type="text" />
                </div>

      
					 
                {/* Validation for Mobile 10 Digits*/}
                {validationErrors.mobile && <p style={{ color: 'red' }}>{validationErrors.mobile}</p>}
      

        
                <button className="btn btn-success w-100"  type="submit">Submit</button>
              </form>
            </div>
          </div>
        </div>
        {/* Form Scrip End*/}



        </div>
      </div>
    </div>
            
            <div className="footer-nav-area" id="footerNav">
              <div className="container h-100 px-0">
                <div className="suha-footer-nav h-100">
                  <ul className="h-100 d-flex align-items-center justify-content-between ps-0">
                    <li className="active"> <Link to="/user_home" ><i className="lni lni-home"></i>Home </Link> </li>
                    <li><Logout /></li> 
                    
                
                  </ul>
                </div>
              </div>
            </div>


</div>
</div>
  )
}

export default PostBookingUser