import React, { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { FaCalendarAlt } from 'react-icons/fa';
import "./css/bootstrap.min.css";
import "./css/owl.carousel.min.css";
import "./css/font-awesome.min.css";
import "./css/animate.css";
import "./css/font-awesome.min.css";
import "./css/lineicons.min.css";
import "./css/magnific-popup.css";
import "./css/style.css";
import "./js/jquery.min.js";
import "./js/bootstrap.bundle.min.js";

import imgSmall from "./img/core-img/logo-small.png";
import imgBg from "./img/bg-img/9.png";
import Logout from './Logout.jsx';
import Title from './Title.jsx';

const AddSlotOwner = () => {
  const { id } = useParams();
  const [selectedDate, setSelectedDate] = useState(null);
  const [editedComplaint, setEditedComplaint] = useState({
    owneremail: '',
    name: '',
    date: '',
    status: ''
  });

  const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchComplaintDetails = async () => {
      try {
        const response = await fetch(`http://localhost:4000/api/v1/hall/${id}`);
        if (response.ok) {
          const data = await response.json();
          setEditedComplaint({
            name: data.name,
            
          });
        } else {
          console.error('Error fetching Slot data:', response.statusText);
        }
      } catch (error) {
        console.error('Error fetching Slot data:', error.message);
      }
    };

    fetchComplaintDetails();
  }, [id]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditedComplaint({
      ...editedComplaint,
      [name]: value,
    });
  };

  const handleUpdateComplaint = async (e) => {
    const token = localStorage.getItem('token');
    const ownerEmail = decodeURIComponent(document.cookie.replace(/(?:(?:^|.*;\s*)owneremail\s*=\s*([^;]*).*$)|^.*$/, '$1'));
    e.preventDefault();
    try {
        const response = await fetch('http://localhost:4000/api/v1/slot/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-auth-token': token,
            },
            body: JSON.stringify({
                ...editedComplaint,
                owneremail: ownerEmail, 
                date: selectedDate// Include the owneremail in the request body
            }),
        });
      if (response.ok) {
        console.log('Complaint status updated successfully!');
        alert('Complaint status updated successfully!')
        window.location.href = "/view_hall_owner";
      } else {
        console.error('Failed to update complaint status:', response.statusText);
      }
    } catch (error) {
      console.error('Error updating complaint status:', error.message);
    }
    document.cookie = `name=${editedComplaint.name}; path=/`;
  };

  const handleDateChange = (date) => {
    setSelectedDate(date);
    // Additional logic if needed
  };



  return (
    <div>
      <div>
        {/* Header Area */}
        <div className="header-area" id="headerArea">
          <div className="container h-100 d-flex align-items-center justify-content-between">
            <div className="logo-wrapper" style={{ color: '#020310' }}><img src={imgSmall} alt="" /> <Title /> </div>
            <div className="suha-navbar-toggler" data-bs-toggle="offcanvas" data-bs-target="#suhaOffcanvas" aria-controls="suhaOffcanvas"><span></span><span></span><span></span></div>
          </div>
        </div>
        {/* Offcanvas Area */}
        <div className="offcanvas offcanvas-start suha-offcanvas-wrap" id="suhaOffcanvas" aria-labelledby="suhaOffcanvasLabel">
          <button className="btn-close btn-close-white text-reset" type="button" data-bs-dismiss="offcanvas" aria-label="Close"></button>
          <div className="offcanvas-body">
            <div className="sidenav-profile">
              <div className="user-profile"><img src={imgBg} alt="" /></div>
              <div className="user-info">
                <h6 className="user-name mb-1">Event Marriage Hall Booking System</h6>
              </div>
            </div>
            <ul className="sidenav-nav ps-0">
              <li><Link to="/owner_home"><i className="lni lni-home"></i>Home</Link></li>
              <li><Logout /></li>
            </ul>
          </div>
        </div>
      </div>
      {/* Page Content Wrapper */}
      <div className="page-content-wrapper">
        <div className="top-products-area py-3">
          <div className="container">
            <div className="section-heading d-flex align-items-center justify-content-between">
              <h6>Update Status</h6>
            </div>
            <div className="profile-wrapper-area py-3">
              <div className="card user-data-card">
                <div className="card-body">
                  <form onSubmit={handleUpdateComplaint}>
                    <div className="mb-3">
                      <div className="title mb-2"><span>Update Status</span></div>
                      <select
                        name="status"
                        id="status"
                        value={editedComplaint.status}
                        onChange={handleInputChange}>
                          <option value="">Select Status here...</option>
                        <option value="Available">Available</option>
                        <option value="Un-Available">Un-Available</option>
                        
                      </select>
                    </div>
                    <div className="mb-3">
                      <div className="title mb-2"><span>Name</span></div>
                      <input
                        className="form-control"
                        name="name"
                        id="name"
                        value={editedComplaint.name}
                        onChange={handleInputChange}
                        type="text" />
                    </div>
                   

                    <div className="mb-3">
    <div className="title mb-2"><span>Date</span></div>
    <div className="input-group">
        <div className="input-group-prepend">
            <span className="input-group-text">
                <FaCalendarAlt />
            </span>
        </div>
        <DatePicker
            selected={selectedDate}
            onChange={handleDateChange}
            placeholderText="Select date"
            dateFormat="dd/MM/yyyy"
            className="form-control"
        />
    </div>
</div>

                    <button className="btn btn-success w-100" type="submit">Save</button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Footer Nav Area */}
      <div className="footer-nav-area" id="footerNav">
        <div className="container h-100 px-0">
          <div className="suha-footer-nav h-100">
            <ul className="h-100 d-flex align-items-center justify-content-between ps-0">
              <li className="active"> <Link to="/owner_home"><i className="lni lni-home"></i>Home </Link> </li>
              <li><Logout /></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}

export default AddSlotOwner;
