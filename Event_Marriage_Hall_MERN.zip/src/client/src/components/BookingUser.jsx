import React, { useState, useEffect } from 'react';
import { Link , useNavigate} from 'react-router-dom';
import axios from 'axios';
import { useCookies } from 'react-cookie';
import "./css/bootstrap.min.css";
import "./css/owl.carousel.min.css";
import "./css/font-awesome.min.css";
import "./css/animate.css";
import "./css/font-awesome.min.css";
import "./css/lineicons.min.css";
import "./css/magnific-popup.css";
import "./css/style.css";

import "./js/jquery.min.js";  
import "./js/bootstrap.bundle.min.js";

import imgSmall from "./img/core-img/logo-small.png";
import imgBg from "./img/bg-img/9.png";
import imgMech from "./img/mechanic.png";
import Logout from './Logout.jsx';
import Title from './Title.jsx';

const BookingUser = ({ slot }) => {
    const navigate = useNavigate();

    const userBooking = (slot) => {
        // Ensure slot is defined before accessing its properties
        if (!slot) return;

        // Store the slot.date in cookies
        document.cookie = `slotDate=${slot.date}; path=/`;

        // Navigate to the "/post_booking_user" route
        navigate("/post_booking_user");
    };

  const [cookies] = useCookies(['name']);
  const [slotData, setSlotData] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const fetchSlotData = async () => {
        try {
            const response = await axios.get(`http://localhost:4000/api/v1/slot/`);
            if (response.status === 200) {
                setSlotData(response.data);
            } else {
                console.error('Error fetching Slot data:', response.statusText);
            }
        } catch (error) {
            console.error('Error fetching slot data:', error.message);
        }
    };

    fetchSlotData();
}, []);

// Filter data based on the search term and cookies name
const filteredData = slotData.filter((slot) => {
    const isMatch = Object.values(slot).some((field) =>
        field.toString().toLowerCase().includes(searchTerm.toLowerCase())
    );

    // Additional condition to filter based on "Available" status
    const isAvailable = slot.status.toLowerCase() === 'available';

    // Check if the name from cookies matches the slot owner's name
    const isOwnerNameMatch = slot.name.toLowerCase() === cookies.name.toLowerCase();

    return isMatch && isAvailable && isOwnerNameMatch;
});



  const timeOptions = { hour: '2-digit', minute: '2-digit' };
  return (
    <div>
        <div>
      
        <div className="header-area" id="headerArea">
        <div className="container h-100 d-flex align-items-center justify-content-between">
    
        <div className="header-area" id="headerArea">
        <div className="container h-100 d-flex align-items-center justify-content-between">
            <div className="logo-wrapper" style={{color:'#020310'}}><img src={imgSmall} alt=""/> <Title /> </div>
        
            <div className="suha-navbar-toggler" data-bs-toggle="offcanvas" data-bs-target="#suhaOffcanvas" aria-controls="suhaOffcanvas"><span></span><span></span><span></span></div>
        </div>
        </div>  

{/* tabindex="-1" */}
        <div className="offcanvas offcanvas-start suha-offcanvas-wrap"  id="suhaOffcanvas" aria-labelledby="suhaOffcanvasLabel">
      <button className="btn-close btn-close-white text-reset" type="button" data-bs-dismiss="offcanvas" aria-label="Close"></button>

      <div className="offcanvas-body">
        <div className="sidenav-profile">
          <div className="user-profile"><img src={imgBg} alt=""/></div>
          <div className="user-info">
            <h6 className="user-name mb-1">Event Marriage Hall Booking System</h6>
         
          </div>
        </div>
    
        <ul className="sidenav-nav ps-0">
          <li><Link to="/user_home"><i className="lni lni-home"></i>Home</Link></li>
          <li><Logout /></li>  
          </ul>
      </div>
    </div>
      </div>
    </div>
    <div className="page-content-wrapper">
      <div className="top-products-area py-3">
        <div className="container">
          
        <div className="section-heading d-flex align-items-center justify-content-between">
            <h6>Search Slot Available's</h6>
			
          </div>
          <div className="row g-3" >
              <div className="top-search-form">
                <form>
                  <input className="form-control"  type="text"  placeholder="Search..."     value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}  />
                  <button type="submit"><i className="fa fa-search"></i></button>
                </form>
              </div>
            </div>

            <div className="row" style={{marginTop:10}}>
                {filteredData.map((slot) => (
              <div key={slot._id} className="col-12 col-md-6">                                        
        
              <div className="card product-card" style={{marginBottom:10}}>
                <div className="card-body">
                <a className="product-title d-block"  >E-Mail : <b>{slot.owneremail}</b></a>
                      <a className="product-title d-block"  >Hall Name : <b>{slot.name}</b></a>
                      <a className="product-title d-block">Available Date: <b>{slot.date ? new Date(slot.date).toLocaleDateString() : ''}</b></a>
                      <a className="product-title d-block"  >Available Status : {slot.status}</a>
                      
                      
                    </div>
                  </div>   
                  
                  <a className="btn btn-success" onClick={() => userBooking(slot)}>Book Now</a>

        
           

          			 
              </div>


              ))}
              
        </div>
           
        </div>
    </div>


            
            <div className="footer-nav-area" id="footerNav">
              <div className="container h-100 px-0">
                <div className="suha-footer-nav h-100">
                  <ul className="h-100 d-flex align-items-center justify-content-between ps-0">
                    <li className="active"> <Link to="/user_home" ><i className="lni lni-home"></i>Home </Link> </li>
                    <li><Logout /></li> 
                  </ul>
                </div>
              </div>
            </div>



</div>


</div>
</div>
  )
}

export default BookingUser