import React from 'react';

const Title = () => {

  return (
      <>
      Event Marriage Hall Booking System
       </>
  );
};


export default Title;
