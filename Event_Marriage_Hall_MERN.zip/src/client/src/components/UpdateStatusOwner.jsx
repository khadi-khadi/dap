import React, { useState,useEffect } from 'react';
import { Link ,useParams} from 'react-router-dom';

import "./css/bootstrap.min.css";
import "./css/owl.carousel.min.css";
import "./css/font-awesome.min.css";
import "./css/animate.css";
import "./css/font-awesome.min.css";
import "./css/lineicons.min.css";
import "./css/magnific-popup.css";
import "./css/style.css";
import "./js/jquery.min.js";  
import "./js/bootstrap.bundle.min.js";

import imgSmall from "./img/core-img/logo-small.png";
import imgBg from "./img/bg-img/9.png";
import Logout from './Logout.jsx';
import Title from './Title.jsx';

// name  donarname city password phone  locality address city phone 

const UpdateStatusOwner = () => {
  const { id } = useParams(); // Use useParams to get route parameters

  //const id = match.params.id;
  //const [donationData, setDonationData] = useState({});
  
  const [editedBooking, setEditedBooking] = useState({
    status: '',
    inTime: '',
    inDate: '',
    outTime:'',
    outDate: '',
    amount: '',
    paid: '',
    balance: ''
  });
  
  const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchBookingDetails = async () => {
      try {
        const response = await fetch(`http://localhost:4000/api/v1/booking/${id}`);
        if (response.ok) {
          const data = await response.json();
          setEditedBooking({
            status: data.status  ,
          });
        }else {
          console.error('Error fetching User data:', response.statusText);
        } 
      } catch (error) {
        console.error('Error fetching User data:', error.message);
      }
    };

    fetchBookingDetails();
  }, [id]);




  const handleInputChange = (e) => {
    const { name, value } = e.target;
  
    // Calculate the balance if 'amount' or 'paid' changes
    if (name === 'amount' || name === 'paid') {
      const totalRentAmount = parseFloat(name === 'amount' ? value : editedBooking.amount) || 0;
      const paidAmount = parseFloat(name === 'paid' ? value : editedBooking.paid) || 0;
      const balanceAmount = totalRentAmount - paidAmount;
  
      // Update the state with the new balance amount
      setEditedBooking(prevState => ({
        ...prevState,
        balance: balanceAmount.toFixed(2), // Round to 2 decimal places
        [name]: value, // Update the edited value as well
      }));
    } else {
      // Update other input values
      setEditedBooking(prevState => ({
        ...prevState,
        [name]: value,
      }));
    }
  };
  



  const handleUpdateBooking  = async (e) =>  {
    e.preventDefault();
    try {

      const response = await fetch(`http://localhost:4000/api/v1/booking/status/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        'x-auth-token': token,
        },
        body: JSON.stringify(editedBooking),
      });

      if (response.ok) {
        console.log('Status updated successfully!');
        alert('Status updated successfully!')
        // Add any additional logic you need after a successful update
        window.location.href = "/view_booking_owner";

      } else {
        console.error('Not updating booking details:', response.statusText);
      }
    } catch (error) {
      console.error('Error updating booking details:', error.message);
    }
  };

  return (
    <div>
        <div>
      
        <div className="header-area" id="headerArea">
        <div className="container h-100 d-flex align-items-center justify-content-between">
    
        <div className="header-area" id="headerArea">
        <div className="container h-100 d-flex align-items-center justify-content-between">
            <div className="logo-wrapper" style={{color:'#020310'}}><img src={imgSmall} alt=""/> <Title /> </div>
        
            <div className="suha-navbar-toggler" data-bs-toggle="offcanvas" data-bs-target="#suhaOffcanvas" aria-controls="suhaOffcanvas"><span></span><span></span><span></span></div>
        </div>
        </div>  

{/* tabindex="-1" */}
        <div className="offcanvas offcanvas-start suha-offcanvas-wrap"  id="suhaOffcanvas" aria-labelledby="suhaOffcanvasLabel">
      <button className="btn-close btn-close-white text-reset" type="button" data-bs-dismiss="offcanvas" aria-label="Close"></button>

      <div className="offcanvas-body">
        <div className="sidenav-profile">
          <div className="user-profile"><img src={imgBg} alt=""/></div>
          <div className="user-info">
            <h6 className="user-name mb-1">Event Marriage Hall Booking System</h6>
         
          </div>
        </div>
    
        <ul className="sidenav-nav ps-0">
          <li><Link to="/owner_home"><i className="lni lni-home"></i>Home</Link></li>
          <li><Logout /></li>  
          </ul>
      </div>
    </div>
      </div>
    </div>
    <div className="page-content-wrapper">
      <div className="top-products-area py-3">
        <div className="container">
          <div className="section-heading d-flex align-items-center justify-content-between">
            <h6>Update Booking Status</h6>
          </div>
        {/* Form Scrip Start*/}
        <div className="profile-wrapper-area py-3">
          <div className="card user-data-card">
            <div className="card-body">
              <form onSubmit={handleUpdateBooking} >
              <div className="mb-3">
                  <div className="title mb-2"><span>Update Status:</span></div>
                  <select name="status" id="status"
                    value={editedBooking.status}
                    onChange={handleInputChange}  >
                      <option value="Pending">Pending</option>
                      <option value="Booked">Booked</option>
                      <option value="Reject">Reject</option>
                    </select>           
                </div>
            
                <div className="mb-3">
  <div className="title mb-2"><span>Check In Date:</span></div>
  <input
    className="form-control"
    name="inDate"
    id="inDate"
    value={editedBooking.inDate}
    onChange={handleInputChange}
    type="date"
  />
</div>
<div className="mb-3">
  <div className="title mb-2"><span>Check In Time:</span></div>
  <input
    className="form-control"
    name="inTime"
    id="inTime"
    value={editedBooking.inTime}
    onChange={handleInputChange}
    type="time"
  />
</div>
<div className="mb-3">
  <div className="title mb-2"><span>Check Out Date:</span></div>
  <input
    className="form-control"
    name="outDate"
    id="outDate"
    value={editedBooking.outDate}
    onChange={handleInputChange}
    type="date"
  />
</div>
<div className="mb-3">
  <div className="title mb-2"><span>Check Out Time:</span></div>
  <input
    className="form-control"
    name="outTime"
    id="outTime"
    value={editedBooking.outTime}
    onChange={handleInputChange}
    type="time"
  />
</div>

                
                <div className="mb-3">
  <div className="title mb-2"><span>Total Rent Amount:</span></div>
  <input
    className="form-control"
    name="amount"
    id="amount"
    value={editedBooking.amount}
    onChange={handleInputChange}
    type="text"
  />
</div> 
<div className="mb-3">
  <div className="title mb-2"><span>Paid Amount:</span></div>
  <input
    className="form-control"
    name="paid"
    id="paid"
    value={editedBooking.paid}
    onChange={handleInputChange}
    type="text"
  />
</div> 
<div className="mb-3">
  <div className="title mb-2"><span>Balance Amount:</span></div>
  <input
    className="form-control"
    name="balance"
    id="balance"
    value={editedBooking.balance}
    type="text"
    readOnly // Make the balance input read-only
  />
</div>


                <button  className="btn btn-success w-100"  type="submit">Save</button>
              </form>
            </div>
          </div>
        </div>
        {/* Form Scrip End
        */}



        </div>
      </div>
    </div>
            
            <div className="footer-nav-area" id="footerNav">
              <div className="container h-100 px-0">
                <div className="suha-footer-nav h-100">
                  <ul className="h-100 d-flex align-items-center justify-content-between ps-0">
                    <li className="active"> <Link to="/owner_home" ><i className="lni lni-home"></i>Home </Link> </li>
                    <li><Logout /></li> 
                    
                
                  </ul>
                </div>
              </div>
            </div>


</div>
</div>
  )
}

export default UpdateStatusOwner