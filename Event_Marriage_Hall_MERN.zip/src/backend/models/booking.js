const mongoose = require('mongoose');

const bookingSchema = mongoose.Schema({
    owneremail: {
        type: String,
        required: true,    
    },
    email: {
        type: String,
        required: true,    
    },
    name: {
        type: String,
        required: true,    
    },
    slotDate: {
        type: String,
        required: true,    
    } ,
    cusname: {
        type: String,
        required: true,    
    } ,
    functionfor: {
        type: String,
        required: true,    
    } ,
    functiontype: {
        type: String,
        required: true,    
    } ,
    guestcount: {
        type: String,
        required: true,    
    } ,
    mobile: {
        type: String,
        required: true,    
    } ,
    address: {
        type: String,
        required: true,    
    } ,
    status: {
        type: String,
        default: 'Pending',   
    },
    inTime: {
        type: String,
        default: 'Nil',    
    } ,
    inDate: {
        type: String,
        default: 'Nil',    
    } ,
    outTime: {
        type: String,
        default: 'Nil',   
    } ,
    outDate: {
        type: String,
        default: 'Nil',    
    } ,
    amount: {
        type: String,
        default: 'Nil',    
    } ,
    paid: {
        type: String,
        default: 'Nil',   
    } ,
    balance: {
        type: String,
        default: 'Nil',    
    } ,
    dateCreated: {
        type: Date,
        default: Date.now
    },
    
})


bookingSchema.virtual('id').get(function () {
    return this._id.toHexString();
});

bookingSchema.set('toJSON', {
    virtuals: true,
});


exports.Booking = mongoose.model('Booking', bookingSchema);
