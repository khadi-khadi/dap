const mongoose = require('mongoose');

const slotSchema = mongoose.Schema({
    owneremail: {
        type: String,
        required: true,    
    },
    name: {
        type: String,
        required: true,    
    },
    date: {
        type: String,
        required: true, 
    }, 
    status: {
        type: String,
        default: 'Pending',   
    },
    dateCreated: {
        type: Date,
        default: Date.now
    },
})


slotSchema.virtual('id').get(function () {
    return this._id.toHexString();
});

slotSchema.set('toJSON', {
    virtuals: true,
});


exports.Slot = mongoose.model('Slot', slotSchema);
