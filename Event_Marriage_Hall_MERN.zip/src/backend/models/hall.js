const mongoose = require('mongoose');

const hallSchema = mongoose.Schema({
    owneremail: {
        type: String,
        required: true,    
    },
    name: {
        type: String,
        required: true,    
    },
    mobile: {
        type: Number,
        required: true,  
    },
    address: {
        type: String,
        required: true,    
    },
    city: {
        type: String,
        required: true,    
    },
    facility: {
        type: String,
        required: true,    
    },
    price: {
        type: String,
        required: true,    
    },
    image: {
        type: String, // Assuming imagePath is a string containing the path to the image file
                         // Optional: Provide a default value if no image is uploaded
      },
    status:{
        type: String,
        default:'Pending'
    },
    lat: {
        type: Number,  
        default: 0,         
    },
    long: {
        type: Number,
        default: 0,   
    },
    
    
    dateCreated: {
        type: Date,
        default: Date.now,
    }
})


hallSchema.virtual('id').get(function () {
    return this._id.toHexString();
});

hallSchema.set('toJSON', {
    virtuals: true,
});


exports.Hall = mongoose.model('Hall', hallSchema);
