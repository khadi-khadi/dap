const {Hall} = require('../models/hall');
const express = require('express');
const router = express.Router();
const auth = require('../helpers/jwt');
const multer = require('multer');


// Set up multer storage for storing uploaded images
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, 'public/uploads/');
    },
    filename: function (req, file, cb) {
      cb(null, Date.now() + '-' + file.originalname);
    },
  });
  
  const upload = multer({ storage: storage });






router.get(`/`,  async (req, res) =>{
    const hallList = await Hall.find();

    if(!hallList) {
        res.status(500).json({success: false})
    } 
    res.status(200).send(hallList);
})



router.get(`/:id`, async (req, res) =>{
    const hallList = await Hall.findById(req.params.id);

    if(!hallList) {
        res.status(500).json({success: false})
    } 
    res.send(hallList);
})


router.post('/',  async (req,res)=>{
    let hall = new Hall({
        
        owneremail: req.body.owneremail,
        name: req.body.name,
        mobile: req.body.mobile,
        address: req.body.address,
        city: req.body.city,
        facility: req.body.facility,
        price: req.body.price,
        
       
        //status: req.body.status
    })
    hall = await hall.save();

    if(!hall)
    return res.status(400).send('the hall cannot be created!')
    res.send(hall);
    
})



router.delete('/:id', auth, (req, res)=>{
    Hall.findByIdAndRemove(req.params.id).then(hall =>{
        if(hall) {
            return res.status(200).json({success: true, message: 'the hall is deleted!'})
        } else {
            return res.status(404).json({success: false , message: "hall not found!"})
        }
    }).catch(err=>{
       return res.status(500).json({success: false, error: err}) 
    })
})



router.put('/:id',async (req, res)=> {
    const hall = await Hall.findByIdAndUpdate(
        req.params.id,
        {        
            owneremail: req.body.owneremail,
            name: req.body.name,
            mobile: req.body.mobile,
            address: req.body.address,
            city: req.body.city,
            facility: req.body.facility,
            price: req.body.price,
        },
        { new: true}
    )

    if(!hall)
    return res.status(400).send('the hall cannot be created!')

    res.send(hall);
})




router.put('/map/:id',async (req, res)=> {
    const hall = await Hall.findByIdAndUpdate(
        req.params.id,
        {        
            lat: req.body.lat,
            long: req.body.long
        },
        { new: true}
    )

    if(!hall)
    return res.status(400).send('the hall cannot be created!')

    res.send(hall);
})



router.put('/status/:id', auth, async (req, res)=> {
    const hall = await Hall.findByIdAndUpdate(
        req.params.id,
        {        
            status: req.body.status
        },
        { new: true}
    )

    if(!hall)
    return res.status(400).send('the hall cannot be created!')

    res.send(hall);
})





// PUT route to update the status and upload an image for a hall
router.put('/upload_image/:id', auth, upload.single('image'), async (req, res) => {
    try {
      const hallId = req.params.id;
      //const { status, reason, remedies, notes } = req.body;
      const image = req.file ? req.file.path : undefined;
  
      // Find the hall by ID and update its status and image path
      const updatedHall = await Hall.findByIdAndUpdate(
        hallId,
        { $set: {image } },
        { new: true } // To return the updated document
      );
  
      if (!updatedHall) {
        return res.status(404).json({ success: false, message: 'hall not found' });
      }
  
      res.status(200).json({ success: true, message: 'hall status and image updated successfully', hall: updatedHall });
    } catch (error) {
      console.error('Error updating hall status and image:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  });




module.exports =router;