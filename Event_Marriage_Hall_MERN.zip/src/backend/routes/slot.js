const {Slot} = require('../models/slot');
const express = require('express');
const router = express.Router();
const auth = require('../helpers/jwt');

// name description mechanicname service available  locality address city mobile 

router.get(`/`,  async (req, res) =>{
    const slotList = await Slot.find();

    if(!slotList) {
        res.status(500).json({success: false})
    } 
    res.status(200).send(slotList);
})



router.get(`/:id`, async (req, res) =>{
    const slotList = await Slot.findById(req.params.id);

    if(!slotList) {
        res.status(500).json({success: false})
    } 
    res.send(slotList);
})


router.post('/',  async (req,res)=>{
    let slot = new Slot({
        
        owneremail: req.body.owneremail,
        name: req.body.name,
        date: req.body.date,
        status: req.body.status,
        
        
        

    })
    slot = await slot.save();

    if(!slot)
    return res.status(400).send('the slot cannot be created!')
    res.send(slot);
    
})

{/*
router.post('/status/:id', auth, async (req, res)=> {
    const slot = await Slot.findByIdAndUpdate(
        req.params.id,
        {        
            status: req.body.status,
            
        },
        { new: true}
    )

    if(!slot)
    return res.status(400).send('the slot cannot be created!')

    res.send(slot);
})



router.put('/map/:id',async (req, res)=> {
    const booking = await Location.findByIdAndUpdate(
        req.params.id,
        {        
            lat: req.body.lat,
            long: req.body.long
        },
        { new: true}
    )
    if(!booking)
    return res.status(400).send('the business cannot be created!')

    res.send(booking);
})

*/}
module.exports =router;