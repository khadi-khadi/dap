
const {Booking} = require('../models/booking');
const express = require('express');
const router = express.Router();
const auth = require('../helpers/jwt');

// Get all bookings
router.get('/', async (req, res) => {
    try {
        const bookingList = await Booking.find();
        res.status(200).json(bookingList);
    } catch (error) {
        console.error('Error fetching booking data:', error.message);
        res.status(500).json({ message: 'Failed to fetch booking data' });
    }
});

// Get booking by ID
router.get('/:id', async (req, res) => {
    try {
        const booking = await Booking.findById(req.params.id);
        if (!booking) {
            return res.status(404).json({ message: 'Booking not found' });
        }
        res.json(booking);
    } catch (error) {
        console.error('Error fetching booking data:', error.message);
        res.status(500).json({ message: error.message });
    }
});



router.post('/',  async (req,res)=>{
    let booking = new Booking({
        
        owneremail: req.body.owneremail,
        email: req.body.email,
        name: req.body.name,
        slotDate: req.body.slotDate,
        cusname: req.body.cusname,
        functionfor: req.body.functionfor,
        functiontype: req.body.functiontype,
        guestcount: req.body.guestcount,
        mobile: req.body.mobile,
        address: req.body.address,
        

    })
    booking = await booking.save();

    if(!booking)
    return res.status(400).send('the booking cannot be created!')
    res.send(booking);
    
})


router.put('/status/:id', auth, async (req, res)=> {
    const booking = await Booking.findByIdAndUpdate(
        req.params.id,
        {         
            status: req.body.status,
            inTime: req.body.inTime,
            inDate: req.body.inDate,
            outTime: req.body.outTime,
            outDate: req.body.outDate,
            amount: req.body.amount,
            paid: req.body.paid,
            balance: req.body.balance
        },
        { new: true}
    )

    if(!booking)
    return res.status(400).send('the booking cannot be created!')

    res.send(booking);
})



router.put('/map/:id',async (req, res)=> {
    const booking = await Location.findByIdAndUpdate(
        req.params.id,
        {        
            lat: req.body.lat,
            long: req.body.long
        },
        { new: true}
    )
    if(!booking)
    return res.status(400).send('the business cannot be created!')

    res.send(booking);
})


module.exports =router;